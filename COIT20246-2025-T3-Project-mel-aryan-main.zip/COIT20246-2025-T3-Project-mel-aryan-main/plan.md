# Project Plan
This section presents the initial plan for the project.

[Communication](#communication-plan) | [Schedule](#schedule) | [Network Design](./network.md) | [Cloud Services](./cloud.md) | [Security](./security.md) | [Ethics](./ethics.md) | [Reflection](./reflection.md) | [Return to index](./README.md)

## Communication Plan


## Schedule
The plan of tasks for each group member for the remainder of the project is:

- Week 5: 
- Week 6:
- Week 7:
- Week 8:
- Week 9:
- Week 10:
- Week 11: Submit the project
