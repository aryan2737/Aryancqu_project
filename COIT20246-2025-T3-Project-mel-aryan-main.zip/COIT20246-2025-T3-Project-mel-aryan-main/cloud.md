# Cloud Services
This section gives pricing for a cloud setup for the company.

[Cloud VM Provider Comparison](#cloud-vm-provider-comparison) | [Total Cost](#total-cost-of-cloud-vms) | [Plan](./plan.md) | [Network Design](./network.md) | [Security](./security.md) | [Ethics](./ethics.md) | [Reflection](./reflection.md) | [Return to index](./README.md)

## Cloud VM Provider Comparison

Write your answer here.

Links to cloud provider export files:
- [AWS](./) 
- [Azure](./)

If Google is used, then replace one of the above. Make sure the links to the export files work and the files are inside your repository. Delete this paragraph before submission.

## Total Cost of Cloud VMs

Write your answer here.
