# Ethical Issues
This section discusses the different ethical issues that arise in the scenario.

[Data Privacy](#data-privacy-and-security-issues) | [Plan](./plan.md) | [Network Design](./network.md) | [Cloud Services](./cloud.md) | [Security](./security.md) | [Reflections](./reflections.md) | [Return to index](./README.md)

## Data Privacy and Security Issues

Write your answer here.
