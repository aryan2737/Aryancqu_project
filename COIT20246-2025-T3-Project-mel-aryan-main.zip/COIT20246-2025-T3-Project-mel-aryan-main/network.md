# Network Design
This section gives the detailed network design.

[Assumptions](#assumptions) | [Network Design Diagrams and Justifications](#network-design-diagrams-and-justifications) | [WiFi Design](#wifi-design) | [Address Allocations](#address-allocations) | [Recommended Hardware](#recommended-hardware) | [Plan](./plan.md) | [Cloud Services](./cloud.md) | [Security](./security.md) | [Ethics](./ethics.md) | [Reflection](./reflection.md) | [Return to index](./README.md)

## Assumptions

Write your answer here.

## Network Design Diagrams and Justifications

Write your answer here. Ensure you embed images of the network design, and link to the drawio files. The drawio files must be in your repository. 

## WiFi Design

Write your answere here.

## Address Allocations

Write your answer here.

## Recommended Hardware

Write your answer here.
